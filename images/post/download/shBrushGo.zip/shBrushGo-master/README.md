shBrushGo
=========

shBrushGo is a brush for [Alex Gorbatchev's SyntaxHighlighter](http://alexgorbatchev.com/SyntaxHighlighter/) allowing syntax highlighting for the [Go programming language](http://golang.org/).

Usage
-----
Download shBrushGo.js and put it in your web server.

In your html page, add a reference to both Alex Gorbatchev's SyntaxHighlighter scripts and shBrushGo.js.

Then use either "go" or "golang" as alias when you insert golang code.

